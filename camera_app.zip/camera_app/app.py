#!/usr/bin/env python3
"""
macOS Camera App — Flask + OpenCV + PyWebView
Launch: camera  (after install.sh)
"""

import cv2
import numpy as np
import os
import base64
import threading
import time
from datetime import datetime
from pathlib import Path
from flask import Flask, Response, render_template, jsonify, send_file

SAVE_DIR = Path.home() / "Pictures" / "CameraApp"
SAVE_DIR.mkdir(parents=True, exist_ok=True)
THUMBNAIL_COUNT = 10
HOST = "127.0.0.1"
PORT = 5001

app = Flask(__name__)
camera = None
camera_lock = threading.Lock()
latest_frame = None      # raw frame straight from the sensor
frame_lock = threading.Lock()

zoom_level = 1.0          # 1.0 = no zoom, up to 3.0
zoom_lock = threading.Lock()


def get_camera():
    global camera
    with camera_lock:
        if camera is None or not camera.isOpened():
            camera = cv2.VideoCapture(0, cv2.CAP_AVFOUNDATION)
            for w, h in [(3840, 2160), (2560, 1440), (1920, 1080)]:
                camera.set(cv2.CAP_PROP_FRAME_WIDTH, w)
                camera.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
                actual_w = int(camera.get(cv2.CAP_PROP_FRAME_WIDTH))
                if actual_w >= w * 0.9:
                    break
            camera.set(cv2.CAP_PROP_FPS, 30)
            aw = int(camera.get(cv2.CAP_PROP_FRAME_WIDTH))
            ah = int(camera.get(cv2.CAP_PROP_FRAME_HEIGHT))
            print(f"   Camera: {aw}×{ah}")
        return camera


def apply_zoom(frame, level):
    """Digital zoom — crop to center region then upscale back to full frame size."""
    if level <= 1.001:
        return frame
    h, w = frame.shape[:2]
    crop_w = int(w / level)
    crop_h = int(h / level)
    x0 = (w - crop_w) // 2
    y0 = (h - crop_h) // 2
    cropped = frame[y0:y0 + crop_h, x0:x0 + crop_w]
    return cv2.resize(cropped, (w, h), interpolation=cv2.INTER_LINEAR)


def capture_frames():
    global latest_frame
    cam = get_camera()
    while True:
        ok, frame = cam.read()
        if ok:
            with frame_lock:
                latest_frame = cv2.flip(frame, 1)
        else:
            time.sleep(0.01)


def generate_mjpeg():
    while True:
        with frame_lock:
            frame = latest_frame
        if frame is None:
            time.sleep(0.01)
            continue
        with zoom_lock:
            z = zoom_level
        frame = apply_zoom(frame, z)
        ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 88])
        if not ok:
            continue
        yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + buf.tobytes() + b"\r\n"


def sharpen(img):
    """Unsharp mask — counteracts the soft, low-contrast look of raw webcam frames."""
    blurred = cv2.GaussianBlur(img, (0, 0), sigmaX=3)
    sharpened = cv2.addWeighted(img, 1.5, blurred, -0.5, 0)
    hsv = cv2.cvtColor(sharpened, cv2.COLOR_BGR2HSV).astype("float32")
    hsv[..., 1] = np.clip(hsv[..., 1] * 1.12, 0, 255)
    return cv2.cvtColor(hsv.astype("uint8"), cv2.COLOR_HSV2BGR)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/video_feed")
def video_feed():
    return Response(generate_mjpeg(), mimetype="multipart/x-mixed-replace; boundary=frame")


@app.route("/zoom", methods=["POST"])
def set_zoom():
    from flask import request
    data = request.get_json(force=True)
    level = float(data.get("level", 1.0))
    level = max(1.0, min(3.0, level))
    global zoom_level
    with zoom_lock:
        zoom_level = level
    return jsonify({"level": level})


@app.route("/capture", methods=["POST"])
def capture():
    with frame_lock:
        frame = latest_frame
    if frame is None:
        return jsonify({"error": "No frame available"}), 503

    with zoom_lock:
        z = zoom_level
    frame = apply_zoom(frame, z)
    frame = sharpen(frame)

    ts = datetime.now().strftime("photo_%Y%m%d_%H%M%S")
    filename = f"{ts}.jpg"
    filepath = SAVE_DIR / filename

    if not cv2.imwrite(str(filepath), frame, [cv2.IMWRITE_JPEG_QUALITY, 97]):
        return jsonify({"error": "Failed to save"}), 500

    h, w = frame.shape[:2]

    thumb = cv2.resize(frame, (220, 124))
    _, tb = cv2.imencode(".jpg", thumb, [cv2.IMWRITE_JPEG_QUALITY, 78])

    scale = min(1.0, 1800 / w)
    prev = cv2.resize(frame, (int(w * scale), int(h * scale)))
    _, pb = cv2.imencode(".jpg", prev, [cv2.IMWRITE_JPEG_QUALITY, 93])

    return jsonify({
        "filename": filename,
        "resolution": f"{w}×{h}",
        "thumbnail": "data:image/jpeg;base64," + base64.b64encode(tb).decode(),
        "preview":   "data:image/jpeg;base64," + base64.b64encode(pb).decode(),
    })


@app.route("/photo/<filename>")
def serve_photo(filename):
    p = SAVE_DIR / filename
    return send_file(str(p), mimetype="image/jpeg") if p.exists() else ("Not found", 404)


@app.route("/delete/<filename>", methods=["DELETE"])
def delete_photo(filename):
    if "/" in filename or "\\" in filename or ".." in filename:
        return jsonify({"error": "Invalid filename"}), 400
    p = SAVE_DIR / filename
    if not p.exists():
        return jsonify({"error": "File not found"}), 404
    try:
        escaped = str(p).replace('"', '\\"')
        os.system(f'osascript -e "tell app \\"Finder\\" to delete POSIX file \\"{escaped}\\""')
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/thumbnails")
def thumbnails():
    photos = sorted(SAVE_DIR.glob("photo_*.jpg"), key=os.path.getmtime, reverse=True)[:THUMBNAIL_COUNT]
    out = []
    for p in photos:
        img = cv2.imread(str(p))
        if img is None:
            continue
        t = cv2.resize(img, (220, 124))
        _, b = cv2.imencode(".jpg", t, [cv2.IMWRITE_JPEG_QUALITY, 78])
        out.append({"filename": p.name, "thumbnail": "data:image/jpeg;base64," + base64.b64encode(b).decode()})
    return jsonify(out)


@app.route("/open_folder", methods=["POST"])
def open_folder():
    os.system(f'open "{SAVE_DIR}"')
    return jsonify({"ok": True})


def start_flask():
    app.run(host=HOST, port=PORT, debug=False, threaded=True, use_reloader=False)


if __name__ == "__main__":
    threading.Thread(target=capture_frames, daemon=True).start()
    threading.Thread(target=start_flask, daemon=True).start()
    time.sleep(1.2)
    print(f"\n📷  Camera  ·  {SAVE_DIR}\n")
    try:
        import webview
        w = webview.create_window("Camera", f"http://{HOST}:{PORT}",
                                  width=1280, height=860, min_size=(900, 640),
                                  background_color="#000000")
        webview.start(gui="cocoa")
    except ImportError:
        import webbrowser
        webbrowser.open(f"http://{HOST}:{PORT}")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass
