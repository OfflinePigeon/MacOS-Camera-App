#!/bin/bash
# Run once: bash install.sh
# After that, just type: camera

set -e
DIR="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo "📷  Installing Camera App..."
echo ""

pip3 install -q -r "$DIR/requirements.txt"

LAUNCHER=/usr/local/bin/camera
sudo tee "$LAUNCHER" > /dev/null << EOF
#!/bin/bash
python3 "$DIR/app.py"
EOF
sudo chmod +x "$LAUNCHER"

echo ""
echo "✅  Done! Type 'camera' in any Terminal window to launch."
echo ""
