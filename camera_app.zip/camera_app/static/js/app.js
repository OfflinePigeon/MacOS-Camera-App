/* ── Camera App JS ─────────────────────────────────────────────────────────── */

const $ = id => document.getElementById(id);

const shutterBtn  = $("shutterBtn");
const flash       = $("flash");
const grid        = $("grid");
const gridToggle  = $("gridToggle");
const strip       = $("strip");
const shotCount   = $("shotCount");
const counter     = $("counter");
const toast       = $("toast");
const toastText   = $("toastText");
const resLabel    = $("resLabel");
const openFolder  = $("openFolder");

// zoom
const zoomSlider  = $("zoomSlider");
const zoomLabel   = $("zoomLabel");

// lightbox
const lb          = $("lb");
const lbScrim     = $("lbScrim");
const lbImg       = $("lbImg");
const lbClose     = $("lbClose");
const lbFilename  = $("lbFilename");
const lbFinder    = $("lbFinder");
const lbDelete    = $("lbDelete");

// confirm
const confirm_    = $("confirm");
const confirmOk   = $("confirmOk");
const confirmCancel = $("confirmCancel");

let count       = 0;
let capturing   = false;
let toastTimer  = null;
let gridOn      = false;
let activeName  = null;
let activeThumb = null;

// ── Toast ──────────────────────────────────────────────────────────────────
function showToast(msg) {
  toastText.textContent = msg;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3000);
}

// ── Shutter FX ─────────────────────────────────────────────────────────────
function doShutterFX() {
  flash.classList.remove("go");
  void flash.offsetWidth;
  flash.classList.add("go");

  shutterBtn.classList.remove("fired");
  void shutterBtn.offsetWidth;
  shutterBtn.classList.add("fired");
  shutterBtn.addEventListener("animationend", () => shutterBtn.classList.remove("fired"), { once: true });
}

// ── Zoom ───────────────────────────────────────────────────────────────────
function sendZoom(level) {
  fetch("/zoom", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ level }),
  }).catch(() => {});
}

zoomSlider.addEventListener("input", () => {
  const level = parseFloat(zoomSlider.value);
  zoomLabel.textContent = level.toFixed(1) + "×";
  sendZoom(level);
});

// ── Lightbox ───────────────────────────────────────────────────────────────
function openLB(src, filename, thumbEl) {
  activeName  = filename;
  activeThumb = thumbEl;
  lbImg.src   = src;
  lbFilename.textContent = filename;
  lb.classList.add("open");
  lb.setAttribute("aria-hidden", "false");
}

function closeLB() {
  lb.classList.remove("open");
  lb.setAttribute("aria-hidden", "true");
  setTimeout(() => { lbImg.src = ""; }, 250);
}

lbClose.addEventListener("click", closeLB);
lbScrim.addEventListener("click", closeLB);
lbFinder.addEventListener("click", () => fetch("/open_folder", { method: "POST" }));

// ── Delete flow ─────────────────────────────────────────────────────────────
lbDelete.addEventListener("click", () => {
  confirm_.classList.add("open");
  confirm_.setAttribute("aria-hidden", "false");
});

confirmCancel.addEventListener("click", () => {
  confirm_.classList.remove("open");
});

confirmOk.addEventListener("click", async () => {
  confirm_.classList.remove("open");
  if (!activeName) return;

  try {
    const res = await fetch(`/delete/${activeName}`, { method: "DELETE" });
    const data = await res.json();
    if (data.error) { showToast("⚠️ " + data.error); return; }

    if (activeThumb) {
      activeThumb.classList.add("deleting");
      activeThumb.addEventListener("animationend", () => activeThumb.remove(), { once: true });
    }

    count = Math.max(0, count - 1);
    shotCount.textContent = count;

    closeLB();
    showToast("Moved to Trash");
  } catch (err) {
    showToast("Delete failed");
    console.error(err);
  }
});

// ── Add thumbnail ──────────────────────────────────────────────────────────
function addThumb(thumbSrc, previewSrc, filename, prepend = true) {
  const div = document.createElement("div");
  div.className = "thumb" + (prepend ? " new" : "");
  div.title = filename;

  const img = document.createElement("img");
  img.src = thumbSrc;
  img.alt = filename;
  div.appendChild(img);

  div.addEventListener("click", () => {
    openLB(previewSrc || `/photo/${filename}`, filename, div);
  });

  if (prepend) {
    strip.insertBefore(div, strip.firstChild);
    setTimeout(() => div.classList.remove("new"), 1800);
    while (strip.children.length > 10) strip.removeChild(strip.lastChild);
  } else {
    strip.appendChild(div);
  }

  requestAnimationFrame(() => requestAnimationFrame(() => div.classList.add("in")));
  return div;
}

// ── Capture ────────────────────────────────────────────────────────────────
async function capture() {
  if (capturing) return;
  capturing = true;
  shutterBtn.disabled = true;
  doShutterFX();

  try {
    const res  = await fetch("/capture", { method: "POST" });
    const data = await res.json();
    if (data.error) { showToast("⚠️ " + data.error); return; }

    count++;
    shotCount.textContent = count;
    counter.classList.remove("bump");
    void counter.offsetWidth;
    counter.classList.add("bump");

    if (data.resolution) resLabel.textContent = data.resolution;

    addThumb(data.thumbnail, data.preview, data.filename, true);
    showToast(data.filename + (data.resolution ? `  ·  ${data.resolution}` : ""));
  } catch (e) {
    showToast("Connection error");
  } finally {
    setTimeout(() => { capturing = false; shutterBtn.disabled = false; }, 380);
  }
}

// ── Grid ───────────────────────────────────────────────────────────────────
function toggleGrid() {
  gridOn = !gridOn;
  grid.classList.toggle("on", gridOn);
  gridToggle.classList.toggle("on", gridOn);
}

// ── Load existing thumbnails ───────────────────────────────────────────────
async function loadThumbs() {
  try {
    const items = await fetch("/thumbnails").then(r => r.json());
    count = items.length;
    shotCount.textContent = count;
    items.forEach(it => addThumb(it.thumbnail, null, it.filename, false));
  } catch {}
}

// ── Feed reconnect ─────────────────────────────────────────────────────────
const feed = document.getElementById("feed");
feed.addEventListener("error", () => {
  setTimeout(() => { feed.src = "/video_feed?" + Date.now(); }, 1500);
});

// ── Keyboard ───────────────────────────────────────────────────────────────
document.addEventListener("keydown", e => {
  if (confirm_.classList.contains("open")) {
    if (e.key === "Escape") confirm_.classList.remove("open");
    return;
  }
  if (lb.classList.contains("open")) {
    if (e.key === "Escape") closeLB();
    return;
  }
  if (e.code === "Space" && !e.target.matches("input,textarea")) { e.preventDefault(); capture(); }
  if ((e.metaKey || e.ctrlKey) && e.key === "s") { e.preventDefault(); capture(); }
  if ((e.metaKey || e.ctrlKey) && e.key === "g") { e.preventDefault(); toggleGrid(); }
  // Up/Down arrows nudge zoom
  if (e.key === "ArrowUp")   { e.preventDefault(); zoomSlider.value = Math.min(3, parseFloat(zoomSlider.value) + 0.1); zoomSlider.dispatchEvent(new Event("input")); }
  if (e.key === "ArrowDown") { e.preventDefault(); zoomSlider.value = Math.max(1, parseFloat(zoomSlider.value) - 0.1); zoomSlider.dispatchEvent(new Event("input")); }
});

// ── Wire buttons ───────────────────────────────────────────────────────────
shutterBtn.addEventListener("click", capture);
gridToggle.addEventListener("click", toggleGrid);
openFolder.addEventListener("click", () => fetch("/open_folder", { method: "POST" }));

loadThumbs();
